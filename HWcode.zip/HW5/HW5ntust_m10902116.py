from PIL import ImageTk, Image
from tkinter.filedialog import askopenfilename
from sys import exit
import tkinter as tk
import numpy as np
import matplotlib.pyplot as plt



class gui:
  '''create tkinter gui'''
  def __init__(self):
    '''
    self.window: tkinter root window
    self.labels: list, input label and output label
    '''
    self.window = tk.Tk()
    self.window.title('AIP M10902116')
    self.labels = []
    LoadImage(self.window, self.labels)
    ImageHistogram(self.window, self.labels)
    GaussianWhiteNoise(self.window, self.labels)
    WaveletTransform(self.window, self.labels)
    HistogramEqualization(self.window, self.labels)
    self.window.protocol("WM_DELETE_WINDOW", self.destroy)
    self.window.mainloop()

  def destroy(self):
    '''destroy process'''
    for l in self.labels:
      l.destroy()
    self.labels.clear()
    self.window.destroy()
    exit()

  @staticmethod
  def resize_label_image(labels):
    '''
    resize image size in window to make UI fixed.
    labels: list, fix label's image.
    '''
    for l in labels:
      if hasattr(l, 'rphoto'):
        img = l.rphoto.image
        w, h = img.size
        ratio = w / 500
        # Rounding
        h = int(h//ratio) + 1 if (h/ratio - h//ratio) >= 0.5 else int(h//ratio)
        if h > 750:
          # limit height
          h = 750
        if ratio > 1:
          w = 500
          # downsampling
          img = img.resize((w, h), Image.ANTIALIAS)
        # not to do upsampling

        photo = ImageTk.PhotoImage(image=img)
        photo.image = img
        l.photo = photo
        l.configure(image=photo)


class LoadImage:
  '''load image to show'''
  def __init__(self, window, labels):
    self.window = window
    self.labels = labels
    load_btn = tk.Button(self.window, text="Load Image")
    load_btn.place(x=5, y=5)
    load_btn.bind('<Button-1>', self.load_image)


  def load_image(self, event):
    '''press load image buttom to ask file and show it on window.'''

    # clear window -- delete image on window
    for l in self.labels:
      l.destroy()
    self.labels.clear()

    # get file path(string)
    image = askopenfilename(
        title="Select file",
        filetypes=(
        ("jpeg files", "*.jpg"),
        ("bmp file", "*.bmp"),
        ("ppm file", "*.ppm"),
        ("png file", "*.png",)
        )
      )
    # open image from path
    image = Image.open(image)
    # convert image format type
    if image.mode == "RGBA":
      image = image.convert("RGB")

    # show input image on window two times, and add labels to list which can be accessed by other function.
    self.canvas = tk.Canvas(self.window)
    photo = ImageTk.PhotoImage(image=image)
    photo.image = image

    input_label = tk.Label(image=photo)
    input_label.rphoto = photo
    input_label.place(x=0, y=20, relx=.1, rely=.1)
    self.labels.append(input_label)

    output_label = tk.Label(image=photo)
    output_label.rphoto = photo
    output_label.place(x=image.width, y=20, relx=.2, rely=.1)
    self.labels.append(output_label)

    # image layout
    gui.resize_label_image(self.labels)
    # keep window
    self.window.mainloop()


class ImageHistogram:
  '''show input image's grayscale histogram.'''
  def __init__(self, window, labels):
    self.window = window
    self.labels = labels
    func_btn = tk.Button(self.window, text="Histogram")
    func_btn.place(x=120, y=5)
    func_btn.bind('<Button-1>', self.histogram)

  def histogram(self, event):
    '''
    from label get input image(RGB, normally) and convert it to grayscale,  
    update label's image to show  grayscale image, and show histogram.  
    self.labels[0].rphoto.image: input image  
    self.labels[0].rphoto.image: output image  
    '''
    # convert RGB to grayscale
    image = self.labels[0].rphoto.image.convert('L')
    # reshape image to 1-d array to compute histogram
    hist = np.array(image).reshape(-1)
    # build histogram
    fig = plt.figure()
    plt.hist(hist, np.arange(257, dtype=int), facecolor='g', alpha=0.75)
    plt.xlabel('GrayScale')
    plt.ylabel('Quantity')
    plt.title('Histogram of GrayScale')
    plt.grid(True)
    # convert histogram(image) to array, and array to PIL.Image
    img_hist = self.array2image(self.figure2array(fig))

    # update label images on window
    pto_img_gr = ImageTk.PhotoImage(image=image)
    pto_img_gr.image = image
    self.labels[0].configure(image=pto_img_gr)
    self.labels[0].rphoto = pto_img_gr

    pto_img_hist = ImageTk.PhotoImage(image=img_hist)
    pto_img_hist.image = img_hist
    self.labels[1].configure(image=pto_img_hist)
    self.labels[1].rphoto = pto_img_hist
    # image layout
    gui.resize_label_image(self.labels)

  @staticmethod
  def figure2array(figure):
    '''
    convert plt.figure to ndarray(RGB).  
    input:
      figure: plt.figure  
    return:
      ndarray, shape=(w,h,3), dtype=np.uint8  
    '''
    figure.canvas.draw()
    w, h = figure.canvas.get_width_height()
    buf = np.frombuffer(figure.canvas.tostring_rgb(), dtype=np.uint8)
    buf.shape = (w, h, 3)
    return buf

  @staticmethod
  def array2image(arr):
    '''
    Convert arr to bytes, and open image from bytes, if using Image.fromarray directly, image will distort.  
    input:
      arr: ndarray(w, h), dtype=np.uint8  
    return:
      PIL.Image  
    '''
    w, h, _ = arr.shape
    return Image.frombytes("RGB", (w, h) , arr.tobytes())
    

class GaussianWhiteNoise:
  ''' Add Gaussian White Noise to image'''
  def __init__(self, window, labels):
    self.window = window
    self.labels = labels
    func_btn = tk.Button(self.window, text="Gaussian White Noise")
    func_btn.place(x=230, y=5)
    func_btn.bind('<Button-1>', self.add_noise)

  def add_noise(self, event):
    deviation = tk.simpledialog.askfloat("Set up noise factor", "Noise Deviation: ([0, 100])", minvalue=0., maxvalue=100., initialvalue=50.)
    input_array = np.array(self.labels[0].rphoto.image)

    if len(input_array.shape) == 3:
      # RGB image
      h, w, _ = input_array.shape
      noise_matrix = deviation * self.get_noise_array(h ,w)
    else:
      # grayscale image
      h, w = input_array.shape
      noise_matrix = deviation * self.get_noise_array(h ,w, isRGB=False)

    # build gaussian noise histogram
    fig = plt.figure()
    plt.hist(noise_matrix.reshape(-1), 50, facecolor='g', alpha=0.75)
    plt.xlabel('Value')
    plt.ylabel('Quantity')
    plt.title('Histogram of Gaussian White Noise')
    plt.grid(True)

    input_array = input_array.astype(np.float64)
    input_array += noise_matrix
    # restrict to [0, 255]
    input_array[input_array > 255] = 255
    input_array[input_array < 0] = 0
    output = input_array.astype(np.uint8)
    output = Image.fromarray(output)

    # convert histogram(image) to array, and array to PIL.Image
    img_hist = ImageHistogram.array2image(ImageHistogram.figure2array(fig))

    # update label images on window
    pto_output = ImageTk.PhotoImage(image=output)
    pto_output.image = output
    self.labels[0].configure(image=pto_output)
    self.labels[0].rphoto = pto_output

    pto_img_hist = ImageTk.PhotoImage(image=img_hist)
    pto_img_hist.image = img_hist
    self.labels[1].configure(image=pto_img_hist)
    self.labels[1].rphoto = pto_img_hist

    # image layout
    gui.resize_label_image(self.labels)


  def get_noise_array(self, h, w, isRGB=True):
    '''
    produce noise matrix and return it.
    '''
    if w % 2 == 0:
      w = w // 2
      need_padding = False
    else:
      w = (w - 1) // 2
      need_padding = True

    if isRGB:
      # RGB
      phi = np.random.uniform(size=(h, w, 3))
      r = np.random.uniform(size=(h, w, 3))
    else:
      # grayscale
      phi = np.random.uniform(size=(h, w))
      r = np.random.uniform(size=(h, w))

    # duplicate columns
    phi = np.repeat(phi, 2, axis=1)
    r = np.repeat(r, 2, axis=1)
    # even colunm index make cos
    phi[:, ::2] = np.cos(-2 * np.pi * phi[:, ::2])
    # odd colunm index make sin
    phi[:, 1::2] = np.sin(-2 * np.pi * phi[:, 1::2])
    r = (-2 * np.log(r)) ** 0.5
    noise_mat = phi * r

    if need_padding:
      # padding width
      if isRGB:
        # RGB
        noise_mat = np.pad(noise_mat, ((0, 0), (0, 1), (0, 0)), 'constant')
      else:
        # grayscale
        noise_mat = np.pad(noise_mat, ((0, 0), (0, 1)), 'constant')

    return noise_mat


class WaveletTransform:
  '''Haar Wavelet Transform'''

  def __init__(self, window, labels):
    self.window = window
    self.labels = labels
    func_btn = tk.Button(self.window, text="Haar Wavelet Transform")
    func_btn.place(x=410, y=5)
    func_btn.bind('<Button-1>', self.apply_transform)

  def apply_transform(self, event):
    image = self.labels[0].rphoto.image
    # Determine if it is a grayscale image. If it is not, turn to grayscale.
    if not image.mode == 'L':
      image = image.convert('L')

    is_power_of_2 = lambda x: np.log2(x) - int(np.log2(x)) == 0

    # Determine if the size of the image is a square and the one side is power of 2. 
    # If it is a square, use the nearest power of 2 as the size; 
    # if not, use the power of 2 closest to the short side as the size.
    w, h = image.size
    if w == h:
      if not is_power_of_2(w):
        size, is_downsampling = self.determine_size(w)
        if is_downsampling:
          image = image.resize((size, size), Image.ANTIALIAS)
        else:
          image = image.resize((size, size))
    else:
      size = w if w < h else h
      if not is_power_of_2(size):
        size, is_downsampling = self.determine_size(size)
        if is_downsampling:
          image = image.resize((size, size), Image.ANTIALIAS)
      image = image.resize((size, size))
    maxtimes = int(np.log2(image.size[0]))
    times = tk.simpledialog.askinteger("Set up Wavelet Transformation times", f"Times: ([1, {maxtimes}])", minvalue=1, maxvalue=maxtimes, initialvalue=2)
    input_array = np.array(image)
    output_array = self.transform(input_array.astype(np.float64), times)

    output_image = Image.fromarray(output_array.astype(np.uint8))
    pto_input = ImageTk.PhotoImage(image=image)
    pto_input.image = image
    self.labels[0].configure(image=pto_input)
    self.labels[0].rphoto = pto_input

    pto_output = ImageTk.PhotoImage(image=output_image)
    pto_output.image = output_image
    self.labels[1].configure(image=pto_output)
    self.labels[1].rphoto = pto_output

    # image layout
    gui.resize_label_image(self.labels)

  def transform(self, arr, times):
    '''
    Do transformation for many times, and paste result in place.  
    input:
      arr: 2-d array.
      times: int, do transformation for many times.
    output:
      output: 2-d array
    '''
    if times != 1:
      size = arr.shape[0]
      output = np.zeros_like(arr, dtype=arr.dtype)
      for _ in range(times):
        result = self.transform(arr, 1)
        output[:size, :size] = result
        size //= 2
        arr = output[:size, :size]
      return output

    size = arr.shape[0]
    output = np.zeros_like(arr, dtype=arr.dtype)

    for mode in ["LL", "HL","HH", "LH"]:
      result = self.filter2D(mode, arr)
      # build border at lower left corner
      result[:, 0] = 255
      result[-1, :] = 255
      if mode == "LL":
        output[:size//2, :size//2] = result
      elif mode == "HL":
        result *= 2.5
        output[:size//2, size//2:] = result
      elif mode == "HH":
        result *= 3
        output[size//2:, size//2:] = result
      elif mode == "LH":
        result *= 2.5
        output[size//2:, :size//2] = result

    output[output > 255] = 255
    return output

  def filter2D(self, mode, arr):
    '''
    Filter first in the x direction, then filter in the y direction,  
    only make two dimensional filtering on a block.  
    input:  
      mode: str, only four choices, "LL", "LH", "HH", "HL"  
      arr: 2-d array  
    output:  
      2-d array
    '''
    if mode == "LL":
      filters = [np.sum, np.sum]
    elif mode == "LH":
      filters = [np.sum, np.diff]
    elif mode == "HL":
      filters = [np.diff, np.sum]
    elif mode == "HH":
      filters = [np.diff, np.diff]

    arr = arr.copy()
    for idx, f in enumerate(filters):
      if idx == 0:
        # x direction, equivalent to
        # kernel size(h,w): (1, 2)
        # stride(h,w): (1, 2) 
        strides = (arr.strides[0], arr.strides[1] * 2, arr.strides[1])
        shape = (arr.shape[0], arr.shape[1] // 2, 2)
      else:
        # y direction, equivalent to
        # kernel size(h,w): (2, 1)
        # stride(h,w): (2, 1) 
        strides = (arr.strides[1], arr.strides[0] * 2, arr.strides[0])
        shape = (arr.shape[1], arr.shape[0] // 2, 2)
      arr3D = np.lib.stride_tricks.as_strided(arr, shape=shape, strides=strides)
      if f == np.diff:
        # Forward difference
        arr = -0.5 * f(arr3D, axis=2)[..., 0] # 2D array
      else:
        arr = 0.5 * f(arr3D, axis=2) # 2D array

    arr[arr > 255] = 255
    arr[arr < 0] = 0
    return arr.T

  def determine_size(self, length):
    '''
    The new image size is determined by a power of 2 closest to the original image size.  
    input:
      length: int, this integer is a power of 2 impossible.
    output:
      size: int, a power of 2 closest to the original image size.
      is_downsampling: bool, downsampling to new size.
    '''
    size = 2
    while True:
      new_size = size * 2
      if new_size < length:
        size = new_size
      elif abs(new_size - length) >= abs(size - length):
        return size, True
      elif abs(new_size - length) < abs(size - length):
        return new_size, False


class HistogramEqualization:
  ''' Histogram Equalization '''
  def __init__(self, window, labels):
    self.window = window
    self.labels = labels
    func_btn = tk.Button(self.window, text="Histogram Equalization")
    func_btn.place(x=610, y=5)
    func_btn.bind('<Button-1>', self.equalization)
  
  def equalization(self, event):
    image = self.labels[0].rphoto.image
    if not image.mode == 'L':
      image = image.convert('L')
    w, h = image.size
    hist = np.array(image).reshape(-1)
    grayscale_level = 256

    # build original histogram
    original_fig = plt.figure()
    pixels_each_grayscales, _, _ = plt.hist(hist, np.arange(grayscale_level + 1, dtype=int), facecolor='g', alpha=0.75)
    plt.xlabel('GrayScale')
    plt.ylabel('Quantity')
    plt.title('Histogram of GrayScale')
    plt.grid(True)

    # reszie original histogram image and cancatenate images vertically
    original_hist_img = ImageHistogram.array2image(ImageHistogram.figure2array(original_fig))
    original_hist_img = self.resize(image, original_hist_img)

    # build cumulative histogram
    cumulative_hist = pixels_each_grayscales.astype(int).cumsum()
    # g_min is minimum grayscale for which cumulative_hist's pixel number > 0
    g_min = np.argwhere(cumulative_hist>0).min()
    grayscale_transform_arr = np.zeros((grayscale_level),dtype=int)
    for i in range(grayscale_level):
      grayscale_transform_arr[i] = np.round((cumulative_hist[i] - cumulative_hist[g_min]) / (h * w - cumulative_hist[g_min]) * (grayscale_level - 1))
    map_func = lambda x: grayscale_transform_arr[x]
    equalization_img = map_func(hist).astype(np.uint8)

    # build new histogram
    new_fig = plt.figure()
    plt.hist(equalization_img, np.arange(grayscale_level + 1, dtype=int), facecolor='g', alpha=0.75)
    plt.xlabel('GrayScale')
    plt.ylabel('Quantity')
    plt.title('Histogram of GrayScale')
    plt.grid(True)

    # reszie new histogram image and cancatenate images vertically
    new_hist_img = ImageHistogram.array2image(ImageHistogram.figure2array(new_fig))
    equalization_img = Image.fromarray(equalization_img.reshape(h,w), mode='L')
    new_hist_img = self.resize(image, new_hist_img)


    # concatenate histogram and image together
    img_org = self.concat_image_vertical(image, original_hist_img)
    img_new = self.concat_image_vertical(equalization_img, new_hist_img)

    # update image in GUI
    photo_org = ImageTk.PhotoImage(image=img_org)
    photo_org.image = img_org
    self.labels[0].photo = photo_org
    self.labels[0].configure(image=photo_org, height=img_org.height)

    photo_new = ImageTk.PhotoImage(image=img_new)
    photo_new.image = img_new
    self.labels[1].photo = photo_new
    self.labels[1].configure(image=photo_new, height=img_new.height)


  def resize(self, img1, img2):
    '''
    resize img2 and make img2's width is same as img1, but ratio not changed.  
    input:  
      img1, img2: PIL.Image
    output:  
      img2: PIL.Image
    '''
    img1_w, _ = img1.size
    img2_w, img2_h = img2.size
    img2_h = int(np.round(img2_h * img1_w / img2_w))
    img2 = img2.resize((img1_w,img2_h))
    return img2

  def concat_image_vertical(self, img1, img2):
    '''
    concatenate grayscale image vertically.  
    input: 
      img1, img2: PIL.Image, grayscale image  
    output:
      new_img: PIL.Image
    '''
    new_img = Image.new('L', (img1.width, img1.height + img2.height))
    new_img.paste(img1, (0, 0))
    new_img.paste(img2, (0, img1.height))
    return new_img


if __name__ == '__main__':
  g = gui()