from PIL import ImageTk, Image
from tkinter.filedialog import askopenfilename
from sys import exit
import tkinter as tk
import numpy as np
import matplotlib.pyplot as plt




class gui:
  '''create tkinter gui'''
  def __init__(self):
    '''
    self.window: tkinter root window
    self.labels: list, input label and output label
    '''
    self.window = tk.Tk()
    self.window.title('AIP M10902116')
    self.labels = []
    load_image(self.window, self.labels)
    image_histogram(self.window, self.labels)
    self.window.protocol("WM_DELETE_WINDOW", self.destroy)
    self.window.mainloop()

  def destroy(self):
    '''destroy process'''
    for l in self.labels:
      l.destroy()
    self.labels.clear()
    self.window.destroy()
    exit()

  @staticmethod
  def resize_label_image(labels):
    '''
    resize image size in window to make UI fixed.
    labels: list, fix label's image.
    '''
    for l in labels:
      if hasattr(l, 'rphoto'):
        img = l.rphoto.image
        w, h = img.size
        ratio = w / 500
        # Rounding
        h = int(h//ratio) + 1 if (h/ratio - h//ratio) >= 0.5 else int(h//ratio)
        if h > 750:
          # limit height
          h = 750
        if ratio > 1:
          w = 500
          # downsampling
          img = img.resize((w, h), Image.ANTIALIAS)
          # not to do upsampling

        photo = ImageTk.PhotoImage(image=img)
        photo.image = img
        l.photo = photo
        l.configure(image=photo)



class load_image:
  '''load image to show'''
  def __init__(self, window, labels):
    self.window = window
    self.labels = labels
    load_btn = tk.Button(self.window, text="Load Image")
    load_btn.place(x=5, y=5)
    load_btn.bind('<Button-1>', self.load_image)


  def load_image(self, event):
    '''press load image buttom to ask file and show it on window.'''

    # clear window -- delete image on window
    for l in self.labels:
      l.destroy()
    self.labels.clear()

    # get file path(string)
    image = askopenfilename(
        title="Select file",
        filetypes=(
        ("jpeg files", "*.jpg"),
        ("bmp file", "*.bmp"),
        ("ppm file", "*.ppm"),
        ("png file", "*.png",)
        )
      )
    # open image from path
    image = Image.open(image)

    # show input image on window two times, and add labels to list which can be accessed by other function.
    self.canvas = tk.Canvas(self.window)
    photo = ImageTk.PhotoImage(image=image)
    photo.image = image

    input_label = tk.Label(image=photo)
    input_label.rphoto = photo
    input_label.pack(padx=20, pady=70, side='left')
    self.labels.append(input_label)

    output_label = tk.Label(image=photo)
    output_label.rphoto = photo
    output_label.pack(padx=50, pady=70, side='left')
    self.labels.append(output_label)

    # image layout
    gui.resize_label_image(self.labels)
    # keep window
    self.window.mainloop()


class image_histogram:
  '''show input image's grayscale histogram.'''
  def __init__(self, window, labels):
    self.window = window
    self.labels = labels
    func_btn = tk.Button(self.window, text="Histogram")
    func_btn.place(x=120, y=5)
    func_btn.bind('<Button-1>', self.histogram)

  def histogram(self, event):
    '''
    from label get input image(RGB, normally) and convert it to grayscale,  
    update label's image to show  grayscale image, and show histogram.  
    self.labels[0].rphoto.image: input image  
    self.labels[0].rphoto.image: output image  
    '''
    # convert RGB to grayscale
    image = self.labels[0].rphoto.image.convert('L')
    # reshape image to 1-d array to compute histogram
    hist = np.array(image).reshape(-1)
    # build histogram
    fig = plt.figure()
    plt.hist(hist, 50, facecolor='g', alpha=0.75)
    plt.xlabel('GrayScale')
    plt.ylabel('Quantity')
    plt.title('Histogram of GrayScale')
    plt.grid(True)
    # convert histogram(image) to array, and array to PIL.Image
    img_hist = self.array2image(self.figure2array(fig))

    # update label images on window
    pto_img_gr = ImageTk.PhotoImage(image=image)
    pto_img_gr.image = image
    self.labels[0].configure(image=pto_img_gr)
    self.labels[0].rphoto = pto_img_gr

    pto_img_hist = ImageTk.PhotoImage(image=img_hist)
    pto_img_hist.image = img_hist
    self.labels[1].configure(image=pto_img_hist)
    self.labels[1].rphoto = pto_img_hist
    # image layout
    gui.resize_label_image(self.labels)

  @staticmethod
  def figure2array(figure):
    '''
    convert plt.figure to ndarray(RGB).  
    figure: plt.figure  
    return ndarray, shape=(w,h,3), dtype=np.uint8  
    '''
    figure.canvas.draw()
    w, h = figure.canvas.get_width_height()
    buf = np.frombuffer(figure.canvas.tostring_rgb(), dtype=np.uint8)
    buf.shape = (w, h, 3)
    return buf

  @staticmethod
  def array2image(arr):
    '''
    convert arr to bytes, and open image from bytes, if using Image.fromarray directly, image will distort.  
    arr: ndarray(w, h), dtype=np.uint8  
    return PIL.Image  
    '''
    w, h, _ = arr.shape
    return Image.frombytes("RGB", (w, h) , arr.tobytes())
    



if __name__ == '__main__':
  g = gui()