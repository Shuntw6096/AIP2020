from PIL import ImageTk, Image
from tkinter.filedialog import askopenfilename
from sys import exit
import tkinter as tk


class gui:
  '''create tkinter gui'''
  def __init__(self):
    '''
    self.window: tkinter root window
    self.labels: list, input label and output label
    '''
    self.window = tk.Tk()
    self.window.title('AIP M10902116')
    self.labels = []
    LoadImage(self.window, self.labels)
    self.window.protocol("WM_DELETE_WINDOW", self.destroy)
    self.window.mainloop()

  def destroy(self):
    '''destroy process'''
    for l in self.labels:
      l.destroy()
    self.labels.clear()
    self.window.destroy()
    exit()

  @staticmethod
  def resize_label_image(labels):
    '''
    resize image size in window to make UI fixed.
    labels: list, fix label's image.
    '''
    for l in labels:
      if hasattr(l, 'rphoto'):
        img = l.rphoto.image
        w, h = img.size
        ratio = w / 500
        # Rounding
        h = int(h//ratio) + 1 if (h/ratio - h//ratio) >= 0.5 else int(h//ratio)
        if h > 750:
          # limit height
          h = 750
        if ratio > 1:
          w = 500
          # downsampling
          img = img.resize((w, h), Image.ANTIALIAS)
          # not to do upsampling

        photo = ImageTk.PhotoImage(image=img)
        photo.image = img
        l.photo = photo
        l.configure(image=photo)



class LoadImage:
  '''load image to show'''
  def __init__(self, window, labels):
    self.window = window
    self.labels = labels
    load_btn = tk.Button(self.window, text="Load Image")
    load_btn.place(x=5, y=5)
    load_btn.bind('<Button-1>', self.load_image)


  def load_image(self, event):
    '''press load image buttom to ask file and show it on window.'''

    # clear window -- delete image on window
    for l in self.labels:
      l.destroy()
    self.labels.clear()

    # get file path(string)
    image = askopenfilename(
        title="Select file",
        filetypes=(
        ("jpeg files", "*.jpg"),
        ("bmp file", "*.bmp"),
        ("ppm file", "*.ppm"),
        ("png file", "*.png",)
        )
      )
    # open image from path
    image = Image.open(image)
    # convert image format type
    if image.mode == "RGBA":
      image = image.convert("RGB")

    # show input image on window two times, and add labels to list which can be accessed by other function.
    self.canvas = tk.Canvas(self.window)
    photo = ImageTk.PhotoImage(image=image)
    photo.image = image

    input_label = tk.Label(image=photo)
    input_label.rphoto = photo
    input_label.pack(padx=20, pady=70, side='left')
    self.labels.append(input_label)

    output_label = tk.Label(image=photo)
    output_label.rphoto = photo
    output_label.pack(padx=50, pady=70, side='left')
    self.labels.append(output_label)

    # image layout
    gui.resize_label_image(self.labels)
    # keep window
    self.window.mainloop()


if __name__ == '__main__':
  g = gui()